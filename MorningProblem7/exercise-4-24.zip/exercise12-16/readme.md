Recreate this element using CSS and HTML. If you are done, make it SASSy and add hover effects or animations.

The fonts used are Open Sans and Times and you can use whatever way you would like to load them into your project.